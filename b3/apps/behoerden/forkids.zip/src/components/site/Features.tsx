import { FolderLock, Clock, Scale, Users, Map, Mic, Sparkles } from "lucide-react";

const features = [
  {
    icon: FolderLock,
    title: "Evidence Vault",
    desc: "Sicherer, verschlüsselter Speicher für Gerichtsdokumente, E-Mails, WhatsApp-Exporte, Fotos, Atteste und Zeugenaussagen. Jeder Upload erhält einen Zeitstempel.",
  },
  {
    icon: Clock,
    title: "Timeline Builder",
    desc: "Eine vollständige chronologische Fallhistorie — von der ersten Mitteilung bis zur letzten Anhörung. Anwält:innen verstehen die Lage in Minuten.",
  },
  {
    icon: Scale,
    title: "Rechtsdatenbank",
    desc: "Verständliche Erklärungen zu Sorgerecht, Befugnissen des Jugendamts, Berufungsverfahren, Fristen — inklusive Mustervorlagen.",
  },
  {
    icon: Users,
    title: "Community",
    desc: "Moderierte, anonyme Diskussionsräume für Väter, Mütter, Großeltern, Pflegefamilien und erwachsene Betroffene.",
  },
  {
    icon: Map,
    title: "Transparenzkarte",
    desc: "Anonyme Statistiken pro Region: Verfahrensdauer, Kontaktregelungen, erfolgreiche Berufungen. Keine personenbezogenen Daten.",
  },
  {
    icon: Mic,
    title: "Story-Plattform",
    desc: "Familien können ihre Geschichte teilen — als Text, Audio oder Video. Keine Anklagen, sondern: „Das ist uns passiert.“",
  },
  {
    icon: Sparkles,
    title: "KI-Assistent",
    desc: "Spezialisiert auf österreichisches Familienrecht. Erklärt Abläufe und Vorbereitung — niemals Rechtsberatung, immer Orientierung.",
    wide: true,
  },
];

export function Features() {
  return (
    <section id="features" className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow text-muted-foreground">Die Plattform</p>
            <h2 className="display mt-4 text-[clamp(2rem,5vw,4rem)] text-foreground">
              Wikipedia + Dropbox + Reddit + KI <span className="italic text-foreground/60">— für österreichisches Familienrecht.</span>
            </h2>
          </div>
          <p className="max-w-sm text-base text-muted-foreground">
            Sieben Werkzeuge, die zusammen Familien helfen, Verfahren zu verstehen, zu dokumentieren und zu bestehen.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-2xl bg-border md:grid-cols-3">
          {features.map((f, i) => (
            <article
              key={f.title}
              className={`group relative flex flex-col gap-5 bg-background p-8 transition hover:bg-secondary/50 md:p-10 ${
                f.wide ? "md:col-span-3" : ""
              }`}
            >
              <div className="flex items-center gap-4">
                <span className="inline-flex h-11 w-11 items-center justify-center rounded-full bg-foreground text-background">
                  <f.icon className="h-5 w-5" strokeWidth={1.6} />
                </span>
                <span className="font-serif text-sm tabular-nums text-muted-foreground">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>
              <h3 className="font-serif text-2xl text-foreground md:text-3xl">{f.title}</h3>
              <p className="max-w-md text-[15px] leading-relaxed text-foreground/70">{f.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}