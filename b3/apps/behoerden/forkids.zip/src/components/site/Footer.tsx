export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-10 px-6 py-16 md:grid-cols-4 md:px-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="inline-block h-2.5 w-2.5 rounded-full bg-accent" aria-hidden />
            <span className="font-serif text-xl tracking-tight text-foreground">
              KinderStimme Österreich
            </span>
          </div>
          <p className="mt-4 max-w-sm font-serif text-lg italic text-foreground/70">
            „Jedes Kind verdient eine faire Stimme."
          </p>
        </div>
        <div>
          <p className="eyebrow text-muted-foreground">Plattform</p>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><a href="#features" className="hover:text-foreground">Evidence Vault</a></li>
            <li><a href="#features" className="hover:text-foreground">Rechtsdatenbank</a></li>
            <li><a href="#features" className="hover:text-foreground">KI-Assistent</a></li>
            <li><a href="#stories" className="hover:text-foreground">Geschichten</a></li>
          </ul>
        </div>
        <div>
          <p className="eyebrow text-muted-foreground">Organisation</p>
          <ul className="mt-4 space-y-2.5 text-sm text-foreground/80">
            <li><a href="#mission" className="hover:text-foreground">Mission</a></li>
            <li><a href="#transparenz" className="hover:text-foreground">Transparenz</a></li>
            <li><a href="#" className="hover:text-foreground">Datenschutz</a></li>
            <li><a href="#" className="hover:text-foreground">Kontakt</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-3 px-6 py-6 text-xs text-muted-foreground md:flex-row md:items-center md:px-10">
          <p>© {new Date().getFullYear()} KinderStimme Österreich · Gemeinnützige Initiative</p>
          <p>Ende-zu-Ende verschlüsselt · DSGVO-konform · Anonym nutzbar</p>
        </div>
      </div>
    </footer>
  );
}