export function Mission() {
  return (
    <section id="mission" className="border-y border-border bg-secondary/40">
      <div className="mx-auto max-w-5xl px-6 py-24 md:px-10 md:py-32">
        <p className="eyebrow text-accent">Unser Auftrag</p>
        <p className="display mt-6 text-[clamp(1.75rem,3.5vw,3rem)] text-foreground">
          Jedes Kind verdient ein <em className="text-accent not-italic">faires</em>, transparentes und evidenzbasiertes Verfahren.
        </p>
        <p className="mt-8 max-w-2xl text-lg leading-relaxed text-foreground/75">
          Eltern, Großeltern, Pflegefamilien und Fachkräfte sollen Zugang zu Werkzeugen haben, die helfen, Fakten zu dokumentieren, Beweise zu sichern und rechtliche sowie psychologische Unterstützung zu finden.
        </p>
      </div>
    </section>
  );
}