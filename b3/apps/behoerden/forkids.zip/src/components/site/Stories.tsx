const stories = [
  {
    role: "Vater, 41 · Steiermark",
    quote: "Nach 14 Monaten ohne Kontakt zu meiner Tochter brauchte ich einen Ort, an dem ich alles ordnen konnte. Hier liegt jetzt jede E-Mail, jedes Protokoll.",
  },
  {
    role: "Großmutter · Wien",
    quote: "Ich verstand das Verfahren nicht mehr. Die Erklärungen in einfacher Sprache haben mir Würde zurückgegeben.",
  },
  {
    role: "Pflegemutter · Oberösterreich",
    quote: "Wir wollten kein Schlachtfeld. Wir wollten Klarheit für das Kind — und wir haben sie bekommen.",
  },
];

export function Stories() {
  return (
    <section id="stories" className="border-y border-border bg-secondary/30 py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow text-muted-foreground">Geschichten</p>
            <h2 className="display mt-4 text-[clamp(2rem,5vw,4rem)] text-foreground">
              „Das ist uns passiert."
            </h2>
          </div>
          <a href="#" className="text-sm font-medium text-foreground underline underline-offset-4">
            Alle Geschichten lesen →
          </a>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
          {stories.map((s, i) => (
            <figure
              key={i}
              className="flex h-full flex-col justify-between rounded-2xl border border-border bg-background p-8 md:p-10"
            >
              <blockquote className="font-serif text-xl leading-snug text-foreground md:text-2xl">
                <span className="text-accent">„</span>
                {s.quote}
                <span className="text-accent">"</span>
              </blockquote>
              <figcaption className="mt-10 text-sm text-muted-foreground">— {s.role}</figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
}