export function CTA() {
  return (
    <section className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-5xl px-6 text-center md:px-10">
        <p className="eyebrow text-accent">Bewegung</p>
        <h2 className="display mt-6 text-[clamp(2.25rem,6vw,5rem)] text-foreground">
          Nicht gegen Institutionen.
          <br />
          <em className="not-italic text-accent">Für Kinder.</em>
        </h2>
        <p className="mx-auto mt-8 max-w-2xl text-lg leading-relaxed text-foreground/75">
          Werden Sie Teil einer Bewegung, die Familien stärkt, Verfahren verbessert und das Wohl der Kinder in den Mittelpunkt stellt.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <a href="#start" className="inline-flex items-center gap-2 rounded-full bg-foreground px-7 py-4 text-sm font-medium text-background transition hover:bg-foreground/90">
            Jetzt mitmachen →
          </a>
          <a href="#legal" className="inline-flex items-center gap-2 rounded-full border border-foreground/15 px-7 py-4 text-sm font-medium text-foreground transition hover:bg-foreground/5">
            Newsletter abonnieren
          </a>
        </div>
      </div>
    </section>
  );
}