import { Link } from "@tanstack/react-router";

export function Nav() {
  return (
    <header className="absolute top-0 left-0 right-0 z-30">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6 md:px-10 md:py-8">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="inline-block h-2.5 w-2.5 rounded-full bg-accent" aria-hidden />
          <span className="font-serif text-xl tracking-tight text-foreground">
            KinderStimme <span className="text-muted-foreground">Österreich</span>
          </span>
        </Link>
        <nav className="hidden items-center gap-9 text-sm text-foreground/80 md:flex">
          <a href="#mission" className="hover:text-foreground">Mission</a>
          <a href="#features" className="hover:text-foreground">Plattform</a>
          <a href="#stories" className="hover:text-foreground">Geschichten</a>
          <a href="#transparenz" className="hover:text-foreground">Transparenz</a>
        </nav>
        <a
          href="#start"
          className="hidden rounded-full border border-foreground/15 bg-foreground px-5 py-2.5 text-sm font-medium text-background transition hover:bg-foreground/90 md:inline-block"
        >
          Fall dokumentieren
        </a>
      </div>
    </header>
  );
}