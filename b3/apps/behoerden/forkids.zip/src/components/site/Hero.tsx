import heroImg from "@/assets/hero-hands.jpg";

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-background pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="pointer-events-none absolute -top-32 -right-32 h-[520px] w-[520px] rounded-full bg-accent/10 blur-3xl" aria-hidden />
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-6 md:grid-cols-12 md:gap-10 md:px-10">
        <div className="md:col-span-7 md:pr-6">
          <p className="eyebrow text-muted-foreground">
            <span className="mr-2 inline-block h-px w-8 translate-y-[-4px] bg-foreground/40 align-middle" />
            Für Familien in Österreich
          </p>
          <h1 className="display mt-6 text-[clamp(2.75rem,7vw,5.75rem)] text-foreground">
            Kinder brauchen<br />
            <span className="italic text-foreground/90">eine Stimme.</span>
          </h1>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-foreground/75 md:text-xl">
            Nicht jede Familie erlebt ein faires Verfahren. Unsere Plattform hilft dabei, Dokumente sicher zu verwalten, Abläufe zu verstehen und Betroffene miteinander zu vernetzen.
          </p>
          <p className="mt-4 text-base text-muted-foreground">
            Mehr Transparenz. Mehr Unterstützung. Mehr Kinderschutz.
          </p>

          <div id="start" className="mt-10 flex flex-wrap items-center gap-3">
            <a href="#features" className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3.5 text-sm font-medium text-background transition hover:bg-foreground/90">
              Fall dokumentieren
              <span aria-hidden>→</span>
            </a>
            <a href="#legal" className="inline-flex items-center gap-2 rounded-full border border-foreground/15 bg-transparent px-6 py-3.5 text-sm font-medium text-foreground transition hover:bg-foreground/5">
              Hilfe finden
            </a>
            <a href="#stories" className="inline-flex items-center gap-2 px-2 py-3.5 text-sm font-medium text-foreground underline-offset-4 hover:underline">
              Geschichten lesen
            </a>
          </div>

          <div className="mt-12 flex items-center gap-6 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-accent" aria-hidden />
              Ende-zu-Ende verschlüsselt
            </div>
            <div className="flex items-center gap-2">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-accent" aria-hidden />
              Anonyme Nutzung möglich
            </div>
            <div className="hidden items-center gap-2 sm:flex">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-accent" aria-hidden />
              DSGVO-konform
            </div>
          </div>
        </div>

        <div className="md:col-span-5">
          <figure className="relative">
            <div className="absolute -inset-3 -z-10 rounded-[2rem] bg-foreground/5" aria-hidden />
            <img
              src={heroImg}
              alt="Eine erwachsene Hand hält die Hand eines Kindes vor einem warm beleuchteten Fenster."
              width={1600}
              height={1280}
              className="aspect-[4/5] w-full rounded-[1.75rem] object-cover shadow-[0_30px_80px_-30px_oklch(0.2_0.04_255_/_0.45)]"
            />
            <figcaption className="mt-5 max-w-sm font-serif text-base italic leading-snug text-foreground/70">
              „Nicht gegen Institutionen. Für Kinder."
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}