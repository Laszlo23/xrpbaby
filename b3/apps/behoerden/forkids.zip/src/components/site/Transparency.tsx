const stats = [
  { value: "1.247", label: "dokumentierte Fälle" },
  { value: "9", label: "Bundesländer abgedeckt" },
  { value: "Ø 14 Monate", label: "durchschnittliche Verfahrensdauer" },
  { value: "23 %", label: "erfolgreiche Berufungen" },
];

export function Transparency() {
  return (
    <section id="transparenz" className="bg-background py-24 md:py-32">
      <div className="mx-auto max-w-7xl px-6 md:px-10">
        <div className="max-w-3xl">
          <p className="eyebrow text-muted-foreground">Öffentliche Transparenz</p>
          <h2 className="display mt-4 text-[clamp(2rem,5vw,4rem)] text-foreground">
            Daten statt Vermutungen.
          </h2>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-foreground/75">
            Anonym, aggregiert, nachvollziehbar. Familien, Journalist:innen und Forschende erhalten einen Überblick darüber, wie Verfahren in Österreich tatsächlich verlaufen.
          </p>
        </div>

        <dl className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl bg-border md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-background p-8 md:p-10">
              <dt className="font-serif text-[clamp(2rem,4vw,3.25rem)] leading-none text-foreground">
                {s.value}
              </dt>
              <dd className="mt-3 text-sm text-muted-foreground">{s.label}</dd>
            </div>
          ))}
        </dl>

        <p className="mt-6 text-xs text-muted-foreground">
          Vorschaudaten · Reale Statistiken erscheinen, sobald genügend Fälle anonym beigetragen wurden.
        </p>
      </div>
    </section>
  );
}