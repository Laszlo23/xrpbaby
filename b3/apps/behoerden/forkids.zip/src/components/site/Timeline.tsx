const events = [
  { date: "12.03.2026", title: "Kontakt verweigert", note: "Mutter dokumentiert verweigerten Umgang per E-Mail." },
  { date: "15.03.2026", title: "Jugendamt-Termin", note: "Protokoll und Gesprächsnotizen werden hochgeladen." },
  { date: "18.03.2026", title: "Psychologisches Gutachten", note: "PDF mit Zeitstempel im Vault gespeichert." },
  { date: "21.03.2026", title: "Gerichtsverhandlung", note: "Vollständige Akte für Anwältin in Minuten verfügbar." },
];

export function Timeline() {
  return (
    <section className="bg-foreground py-24 text-background md:py-32">
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-16 px-6 md:grid-cols-12 md:px-10">
        <div className="md:col-span-5">
          <p className="eyebrow text-background/60">Beispiel · Timeline</p>
          <h2 className="display mt-4 text-[clamp(2rem,4.5vw,3.5rem)] text-background">
            Eine Akte, die für sich spricht.
          </h2>
          <p className="mt-6 max-w-md text-base leading-relaxed text-background/70">
            Jeder Schritt eines Verfahrens wird chronologisch und manipulationssicher festgehalten. Was sonst über Monate in E-Mails verstreut liegt, wird zu einer verständlichen Geschichte.
          </p>
        </div>

        <ol className="relative md:col-span-7 md:pl-10">
          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-background/20 md:left-[7px]" aria-hidden />
          {events.map((e, i) => (
            <li key={i} className="relative grid grid-cols-[auto_1fr] gap-6 pb-10 last:pb-0">
              <span className="relative z-10 mt-1.5 inline-block h-3.5 w-3.5 rounded-full bg-accent ring-4 ring-foreground" aria-hidden />
              <div>
                <p className="font-serif text-sm tabular-nums text-background/60">{e.date}</p>
                <h3 className="mt-1 font-serif text-2xl text-background">{e.title}</h3>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-background/70">{e.note}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}