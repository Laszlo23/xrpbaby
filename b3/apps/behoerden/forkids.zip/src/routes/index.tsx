import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/site/Nav";
import { Hero } from "@/components/site/Hero";
import { Mission } from "@/components/site/Mission";
import { Features } from "@/components/site/Features";
import { Timeline } from "@/components/site/Timeline";
import { Transparency } from "@/components/site/Transparency";
import { Stories } from "@/components/site/Stories";
import { CTA } from "@/components/site/CTA";
import { Footer } from "@/components/site/Footer";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KinderStimme Österreich — Faire Verfahren für Familien" },
      {
        name: "description",
        content:
          "Sichere Dokumentation, Rechtswissen und Community für österreichische Familien. Mehr Transparenz. Mehr Unterstützung. Mehr Kinderschutz.",
      },
      { property: "og:title", content: "KinderStimme Österreich" },
      {
        property: "og:description",
        content: "Nicht gegen Institutionen. Für Kinder. Eine Plattform für Transparenz, Dokumentation und Unterstützung im österreichischen Familienrecht.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="relative min-h-screen bg-background text-foreground">
      <Nav />
      <main>
        <Hero />
        <Mission />
        <Features />
        <Timeline />
        <Transparency />
        <Stories />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
