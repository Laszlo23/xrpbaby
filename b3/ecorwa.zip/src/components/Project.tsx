import { useReveal } from "@/hooks/use-reveal";
import bernhardsthal from "@/assets/bernhardsthal.jpg";
import interior from "@/assets/interior.jpg";
import { ArrowRight } from "lucide-react";

export const Project = () => {
  const ref = useReveal();
  const stats = [
    { v: "14", l: "apartments" },
    { v: "1,200m²", l: "coworking" },
    { v: "1", l: "community kitchen" },
    { v: "8", l: "stays" },
  ];
  return (
    <section id="project" ref={ref} className="relative py-24 md:py-32">
      <div className="container">
        <div className="reveal mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-6">
              / 04 — the first project · bernhardsthal, AT
            </p>
            <h2 className="font-bold uppercase leading-[0.95] tracking-tight" style={{ fontSize: "clamp(2.25rem, 6vw, 5rem)" }}>
              from old <span className="text-muted-foreground/60 line-through">lagerhaus</span><br />
              to <span className="text-acid text-glow">living hub.</span>
            </h2>
          </div>
          <a href="#join" className="btn-ghost-acid self-start md:self-end">
            explore project <ArrowRight size={16} />
          </a>
        </div>

        <div className="reveal grid md:grid-cols-3 gap-4 mb-4">
          <div className="md:col-span-2 relative rounded-2xl overflow-hidden group aspect-[16/10]">
            <img
              src={bernhardsthal}
              alt="Aerial view of Bernhardsthal Lagerhaus at dusk"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-primary mb-2">
                  ● live · acquisition phase
                </div>
                <h3 className="text-2xl md:text-3xl font-bold uppercase">Lagerhaus Bernhardsthal</h3>
              </div>
              <div className="hidden md:block font-mono text-xs text-muted-foreground">48.69°N · 16.86°E</div>
            </div>
          </div>
          <div className="relative rounded-2xl overflow-hidden aspect-[4/5] md:aspect-auto group">
            <img
              src={interior}
              alt="Coworking interior with brick and beams"
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <div className="font-hand text-2xl text-accent text-glow-warm">come live, work, gather.</div>
            </div>
          </div>
        </div>

        <div className="reveal grid grid-cols-2 md:grid-cols-4 gap-px bg-border rounded-2xl overflow-hidden">
          {stats.map((s) => (
            <div key={s.l} className="bg-card p-6 md:p-8">
              <div className="text-3xl md:text-4xl font-bold tracking-tight">{s.v}</div>
              <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
