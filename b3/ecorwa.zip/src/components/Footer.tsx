export const Footer = () => {
  return (
    <footer className="border-t border-border py-12 relative">
      <div className="container flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <span className="relative flex h-2 w-2">
            <span className="absolute inset-0 rounded-full bg-primary pulse-dot" />
            <span className="relative rounded-full h-2 w-2 bg-primary" />
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em]">
            Building<span className="text-acid">.</span>Culture
          </span>
        </div>
        <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground max-w-md">
          a movement to revive places, owned by the people who live them. <br />
          made with care · vienna · 2026
        </p>
        <div className="flex gap-6 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
          <a href="#" className="hover:text-primary">manifesto</a>
          <a href="#" className="hover:text-primary">contact</a>
          <a href="#" className="hover:text-primary">x</a>
        </div>
      </div>
    </footer>
  );
};
