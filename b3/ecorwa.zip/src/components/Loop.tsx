import { useEffect, useRef, useState } from "react";
import { BookOpen, Sparkles, Key, Hammer, Zap, Gift } from "lucide-react";

const steps = [
  { icon: BookOpen, label: "story", desc: "discover a place worth saving" },
  { icon: Sparkles, label: "mint", desc: "claim your piece of it" },
  { icon: Key, label: "ownership", desc: "real share, real rights" },
  { icon: Hammer, label: "revival", desc: "watch it come back to life" },
  { icon: Zap, label: "activation", desc: "use it. live it. share it." },
  { icon: Gift, label: "rewards", desc: "stays, access, returns" },
];

// "real" target numbers
const targets = {
  funding: 612480,   // €
  builders: 1247,
  activations: 384,  // stays + events booked
  places: 3,
};

const fmtEur = (n: number) =>
  "€" + (n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "k" : Math.round(n).toString());

export const Loop = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0); // smoothed 0..1 (drives rail + numbers)
  const [activeStep, setActiveStep] = useState(0);

  // Targets driven by raw scroll, smoothed value driven by rAF
  const targetProgress = useRef(0);
  const smoothProgress = useRef(0);
  const rafId = useRef<number | null>(null);

  useEffect(() => {
    const computeTarget = () => {
      const el = sectionRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const start = vh * 0.85;
      const end = -rect.height + vh * 0.2;
      const raw = (start - rect.top) / (start - end);
      targetProgress.current = Math.max(0, Math.min(1, raw));
    };

    const tick = () => {
      const target = targetProgress.current;
      const current = smoothProgress.current;
      const diff = target - current;
      // Critically-damped-ish lerp; ~12% per frame feels cinematic at 60fps
      const next =
        Math.abs(diff) < 0.0001 ? target : current + diff * 0.12;
      smoothProgress.current = next;
      setProgress(next);
      setActiveStep(Math.min(steps.length - 1, Math.floor(next * steps.length)));
      rafId.current = requestAnimationFrame(tick);
    };

    computeTarget();
    rafId.current = requestAnimationFrame(tick);
    window.addEventListener("scroll", computeTarget, { passive: true });
    window.addEventListener("resize", computeTarget);
    return () => {
      if (rafId.current) cancelAnimationFrame(rafId.current);
      window.removeEventListener("scroll", computeTarget);
      window.removeEventListener("resize", computeTarget);
    };
  }, []);

  // Cinematic easing on top of smoothed progress
  const ease =
    progress < 1 ? 1 - Math.pow(1 - progress, 2.4) : 1;
  const funding = targets.funding * ease;
  const builders = targets.builders * ease;
  const activations = targets.activations * ease;
  const fundingPct = (funding / 900000) * 100; // goal €900k

  return (
    <section
      id="loop"
      ref={sectionRef}
      className="py-32 md:py-44 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.03] to-transparent" />
      <div className="container relative">
        <div className="mb-20 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-6">
              / 03 — the loop
            </p>
            <h2
              className="font-bold uppercase leading-[0.95] tracking-tight"
              style={{ fontSize: "clamp(2.25rem, 6vw, 5rem)" }}
            >
              one cycle. <br />
              <span className="text-acid text-glow">infinite places.</span>
            </h2>
          </div>
          <div className="font-mono text-xs uppercase tracking-widest text-muted-foreground max-w-xs">
            scroll the loop · every step compounds · every person counts
          </div>
        </div>

        {/* Steps with scroll-synced rail */}
        <div className="relative">
          {/* Rail */}
          <div className="hidden md:block absolute top-10 left-[8%] right-[8%] h-px bg-border" />
          <div
            className="hidden md:block absolute top-10 left-[8%] h-px bg-gradient-to-r from-primary via-primary-glow to-accent"
            style={{
              width: `${progress * 84}%`,
              boxShadow: "0 0 20px hsl(var(--primary) / 0.8)",
              transition: "width 120ms linear",
            }}
          />
          {/* Moving pulse */}
          <div
            className="hidden md:block absolute top-10 -translate-x-1/2 -translate-y-1/2 z-10"
            style={{
              left: `calc(8% + ${progress * 84}%)`,
              transition: "left 120ms linear",
            }}
          >
            <span className="relative flex h-3 w-3">
              <span className="absolute inset-0 rounded-full bg-primary pulse-dot" />
              <span className="relative rounded-full h-3 w-3 bg-primary" />
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-6 gap-6 md:gap-2">
            {steps.map((s, i) => {
              const reached = i <= activeStep;
              const current = i === activeStep;
              return (
                <div
                  key={s.label}
                  className="relative flex flex-col items-center text-center"
                >
                  <div
                    className={`relative w-20 h-20 rounded-full flex items-center justify-center mb-5 transition-all duration-500 ${
                      reached
                        ? "bg-primary/10 border border-primary"
                        : "glass"
                    } ${current ? "scale-110" : ""}`}
                    style={
                      reached
                        ? { boxShadow: "0 0 30px hsl(var(--primary) / 0.5)" }
                        : undefined
                    }
                  >
                    <s.icon
                      size={26}
                      className={`transition-colors ${
                        reached ? "text-primary" : "text-muted-foreground"
                      }`}
                    />
                    <span
                      className={`absolute -top-2 -right-2 font-mono text-[10px] rounded-full w-6 h-6 flex items-center justify-center transition-colors ${
                        reached
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background border border-border text-muted-foreground"
                      } border`}
                    >
                      {i + 1}
                    </span>
                  </div>
                  <h4
                    className={`uppercase font-semibold tracking-wider text-sm mb-2 transition-colors ${
                      reached ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {s.label}
                  </h4>
                  <p className="text-xs text-muted-foreground max-w-[140px]">
                    {s.desc}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Live numbers panel */}
        <div className="mt-24 glass rounded-2xl p-8 md:p-10">
          <div className="flex items-center justify-between mb-3">
            <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              first project · funding · live
            </span>
            <span className="font-mono text-sm text-acid tabular-nums">
              {fundingPct.toFixed(1)}% of €900k
            </span>
          </div>
          <div className="h-1.5 bg-border rounded-full overflow-hidden relative">
            <div
              className="h-full bg-gradient-to-r from-primary via-primary-glow to-accent rounded-full"
              style={{
                width: `${(funding / 900000) * 100}%`,
                boxShadow: "0 0 20px hsl(var(--primary) / 0.6)",
                transition: "width 120ms linear",
              }}
            />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-10 pt-8 border-t border-border">
            {[
              { v: fmtEur(funding), l: "raised", sub: "from the community" },
              { v: Math.round(builders).toLocaleString(), l: "builders", sub: "across 14 countries" },
              { v: Math.round(activations).toLocaleString(), l: "activations", sub: "stays · events · access" },
              { v: targets.places.toString(), l: "places", sub: "12 in pipeline" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-3xl md:text-4xl font-bold tracking-tight tabular-nums">
                  {s.v}
                </div>
                <div className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground mt-1">
                  {s.l}
                </div>
                <div className="text-xs text-muted-foreground/70 mt-1">{s.sub}</div>
              </div>
            ))}
          </div>

          <div className="mt-8 flex items-center gap-3 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inset-0 rounded-full bg-primary pulse-dot" />
              <span className="relative rounded-full h-1.5 w-1.5 bg-primary" />
            </span>
            synced · updated as you scroll · step{" "}
            <span className="text-acid">
              {String(activeStep + 1).padStart(2, "0")}
            </span>{" "}
            of {String(steps.length).padStart(2, "0")} —{" "}
            <span className="text-foreground">{steps[activeStep].label}</span>
          </div>
        </div>
      </div>
    </section>
  );
};
