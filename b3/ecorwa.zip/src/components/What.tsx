import { useReveal } from "@/hooks/use-reveal";
import { Users, KeyRound, Shield, Globe2 } from "lucide-react";

const items = [
  { icon: Users, title: "Community-owned hubs", desc: "Real places, owned by the people who use them." },
  { icon: KeyRound, title: "Real-world access", desc: "Stays, coworking, events — not just a screen." },
  { icon: Shield, title: "Onchain transparency", desc: "Every share, every move — verifiable, public, yours." },
  { icon: Globe2, title: "Global network of locals", desc: "One movement. Many villages. Same belonging." },
];

export const What = () => {
  const ref = useReveal();
  return (
    <section id="what" ref={ref} className="py-32 md:py-44 relative">
      <div className="container">
        <div className="reveal max-w-3xl mb-20">
          <p className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-6">/ 02 — what this really is</p>
          <h2 className="font-bold uppercase leading-[0.95] tracking-tight" style={{ fontSize: "clamp(2.25rem, 6vw, 5rem)" }}>
            not real estate. <br />
            <span className="text-acid text-glow">real belonging.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {items.map((it, i) => (
            <div
              key={it.title}
              className="reveal tilt-card group relative p-8 rounded-2xl glass overflow-hidden"
              style={{ transitionDelay: `${i * 100}ms` }}
            >
              <div className="absolute -top-20 -right-20 w-40 h-40 bg-primary/10 rounded-full blur-3xl group-hover:bg-primary/20 transition-all" />
              <div className="relative">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-6">
                  <it.icon size={20} className="text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{it.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{it.desc}</p>
                <div className="mt-6 font-mono text-[10px] uppercase tracking-widest text-primary/60">
                  /0{i + 1}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
