import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { label: "the truth", href: "#truth" },
  { label: "what it is", href: "#what" },
  { label: "the loop", href: "#loop" },
  { label: "project", href: "#project" },
  { label: "network", href: "#network" },
];

export const Nav = () => {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3 bg-background/70 backdrop-blur-xl border-b border-border" : "py-6"
      }`}
    >
      <div className="container flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2.5 group">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inset-0 rounded-full bg-primary pulse-dot" />
            <span className="relative rounded-full h-2.5 w-2.5 bg-primary" />
          </span>
          <span className="font-mono text-xs uppercase tracking-[0.25em]">
            Building<span className="text-acid">.</span>Culture
          </span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-xs font-mono uppercase tracking-widest text-muted-foreground hover:text-primary transition-colors"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <a href="#join" className="hidden md:inline-flex btn-ghost-acid !py-2.5 !px-5 !text-xs">
          join
        </a>

        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)} aria-label="menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden mt-4 mx-4 glass rounded-2xl p-6 flex flex-col gap-4">
          {links.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="text-sm font-mono uppercase tracking-widest">
              {l.label}
            </a>
          ))}
          <a href="#join" onClick={() => setOpen(false)} className="btn-acid !py-3">join the revival</a>
        </div>
      )}
    </header>
  );
};
