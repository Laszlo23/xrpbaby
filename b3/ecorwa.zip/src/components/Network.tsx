import { useReveal } from "@/hooks/use-reveal";

const dots = [
  { x: 48, y: 38, name: "Bernhardsthal", active: true },
  { x: 42, y: 32 }, { x: 35, y: 45 }, { x: 55, y: 30 }, { x: 60, y: 50 },
  { x: 30, y: 55 }, { x: 50, y: 62 }, { x: 65, y: 40 }, { x: 25, y: 35 },
  { x: 70, y: 55 }, { x: 40, y: 70 }, { x: 58, y: 22 }, { x: 38, y: 25 },
  { x: 72, y: 32 }, { x: 22, y: 50 }, { x: 45, y: 55 },
];

export const Network = () => {
  const ref = useReveal();
  return (
    <section id="network" ref={ref} className="py-32 md:py-44 relative overflow-hidden">
      <div className="container">
        <div className="reveal text-center max-w-3xl mx-auto mb-16">
          <p className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-6">/ 05 — the network</p>
          <h2 className="font-bold uppercase leading-[0.95] tracking-tight mb-6" style={{ fontSize: "clamp(2.25rem, 6vw, 5rem)" }}>
            many villages. <br /><span className="text-acid text-glow">one movement.</span>
          </h2>
        </div>

        <div className="reveal relative max-w-5xl mx-auto aspect-[16/10] glass rounded-3xl overflow-hidden">
          <div className="absolute inset-0 bg-grid opacity-20" />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

          {/* Map dots */}
          <svg viewBox="0 0 100 70" className="absolute inset-0 w-full h-full">
            {dots.map((d, i) => (
              <g key={i}>
                {d.active && (
                  <>
                    <circle cx={d.x} cy={d.y} r="3" fill="hsl(var(--primary))" opacity="0.2">
                      <animate attributeName="r" values="3;8;3" dur="2.5s" repeatCount="indefinite" />
                      <animate attributeName="opacity" values="0.6;0;0.6" dur="2.5s" repeatCount="indefinite" />
                    </circle>
                    <circle cx={d.x} cy={d.y} r="1.2" fill="hsl(var(--primary))" />
                    <text x={d.x + 2} y={d.y - 1.5} fontSize="1.6" fill="hsl(var(--primary))" fontFamily="monospace">
                      {d.name}
                    </text>
                  </>
                )}
                {!d.active && (
                  <circle cx={d.x} cy={d.y} r="0.6" fill="hsl(var(--foreground))" opacity="0.4">
                    <animate attributeName="opacity" values="0.2;0.7;0.2" dur={`${3 + (i % 4)}s`} repeatCount="indefinite" />
                  </circle>
                )}
                {!d.active && (
                  <line
                    x1={d.x} y1={d.y} x2={48} y2={38}
                    stroke="hsl(var(--primary))" strokeWidth="0.08" opacity="0.3" strokeDasharray="0.5 0.5"
                  />
                )}
              </g>
            ))}
          </svg>

          <div className="absolute top-6 left-6 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            europe · live network · v0.1
          </div>
          <div className="absolute bottom-6 right-6 font-mono text-[10px] uppercase tracking-widest text-acid">
            ● 1 active · 12 in pipeline · ∞ possible
          </div>
        </div>

        <div className="reveal grid md:grid-cols-3 gap-6 mt-12 max-w-5xl mx-auto">
          {[
            { t: "preserve culture", d: "every saved building keeps a story alive." },
            { t: "create local economy", d: "money stays where it's earned." },
            { t: "reduce empty buildings", d: "rotting space becomes living space." },
          ].map((b) => (
            <div key={b.t} className="p-6 border-l-2 border-primary/40">
              <h4 className="uppercase font-semibold text-sm tracking-wider mb-2">{b.t}</h4>
              <p className="text-sm text-muted-foreground">{b.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
