import community from "@/assets/community.jpg";
import { ArrowRight } from "lucide-react";

export const FinalHook = () => {
  return (
    <section id="join" className="relative min-h-[90vh] flex items-center overflow-hidden">
      <img src={community} alt="people standing together at sunset" loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-background/40" />
      <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-background/50" />

      <div className="container relative z-10 py-32">
        <div className="max-w-4xl">
          <p className="font-mono text-xs uppercase tracking-[0.4em] text-acid mb-8">/ 07 — the hook</p>
          <h2 className="font-bold uppercase leading-[0.9] tracking-tight mb-10" style={{ fontSize: "clamp(2.5rem, 9vw, 8rem)" }}>
            banks said <span className="text-muted-foreground/50">no.</span><br />
            the community <br />
            said <span className="text-acid text-glow">yes.</span>
          </h2>
          <p className="text-lg md:text-2xl font-light text-foreground/80 max-w-2xl mb-12">
            we don't build real estate. <br />
            we build culture — <span className="text-accent">together.</span>
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#" className="btn-acid">become a builder <ArrowRight size={16} /></a>
            <a href="#top" className="btn-ghost-acid">read the manifesto</a>
          </div>
        </div>
      </div>
    </section>
  );
};
