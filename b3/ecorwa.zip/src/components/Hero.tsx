import abandoned from "@/assets/abandoned.jpg";
import revived from "@/assets/revived.jpg";
import { ArrowRight } from "lucide-react";

export const Hero = () => {
  return (
    <section id="top" className="relative min-h-screen overflow-hidden">
      {/* Split background */}
      <div className="absolute inset-0 grid grid-cols-2">
        <div className="relative">
          <img src={abandoned} alt="abandoned village building" className="w-full h-full object-cover grayscale" />
          <div className="absolute inset-0 bg-gradient-to-r from-background/60 via-background/40 to-background/80" />
          <p className="absolute bottom-[18%] left-[8%] font-hand text-3xl md:text-5xl text-foreground/80 rotate-[-4deg] max-w-[200px]">
            this building is dying
          </p>
        </div>
        <div className="relative">
          <img src={revived} alt="revived community building" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-l from-background/60 via-background/40 to-background/80" />
          <p className="absolute bottom-[18%] right-[8%] font-hand text-3xl md:text-5xl text-accent rotate-[3deg] max-w-[260px] text-glow-warm">
            together we bring it back
          </p>
        </div>
      </div>

      {/* Center seam glow */}
      <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-px bg-gradient-to-b from-transparent via-primary/60 to-transparent" />
      <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-32 bg-primary/10 blur-3xl" />

      {/* Top fade for nav legibility */}
      <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-background to-transparent" />
      {/* Bottom fade */}
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-background to-transparent" />

      {/* Center content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-6 text-center pt-24 pb-20">
        <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-2 mb-8 animate-fade-in">
          <span className="relative flex h-2 w-2">
            <span className="absolute inset-0 rounded-full bg-primary pulse-dot" />
            <span className="relative rounded-full h-2 w-2 bg-primary" />
          </span>
          <span className="font-mono text-[11px] uppercase tracking-[0.25em] text-muted-foreground">
            1,247 builders already joined
          </span>
        </div>

        <h1
          className="font-sans font-bold uppercase leading-[0.88] tracking-tight max-w-6xl animate-fade-in"
          style={{ animationDelay: "0.1s", fontSize: "clamp(2.75rem, 9vw, 8rem)" }}
        >
          we bring places <br />
          <span className="text-acid text-glow">back to life.</span>
        </h1>

        <p
          className="mt-8 max-w-xl text-base md:text-xl text-muted-foreground font-light animate-fade-in"
          style={{ animationDelay: "0.25s" }}
        >
          banks see <span className="line-through opacity-60">risk</span>.{" "}
          we see <span className="text-accent">potential</span>.
        </p>

        <div className="mt-12 flex flex-col sm:flex-row gap-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
          <a href="#join" className="btn-acid">
            join the revival <ArrowRight size={16} />
          </a>
          <a href="#project" className="btn-ghost-acid">
            see the first place
          </a>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted-foreground">scroll</span>
          <div className="relative w-px h-12 bg-border overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-4 bg-primary animate-scan" />
          </div>
        </div>
      </div>
    </section>
  );
};
