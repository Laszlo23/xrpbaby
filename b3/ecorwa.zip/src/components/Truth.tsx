import { useReveal } from "@/hooks/use-reveal";

const truths = [
  "villages are dying.",
  "buildings are left to rot.",
  "banks don't take risk.",
  "communities are excluded.",
];

export const Truth = () => {
  const ref = useReveal();
  return (
    <section id="truth" ref={ref} className="relative py-32 md:py-48 overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background" />

      <div className="container relative">
        <p className="reveal font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-12 text-center">
          / 01 — the truth
        </p>

        <div className="max-w-4xl mx-auto space-y-2 md:space-y-4">
          {truths.map((t, i) => (
            <h2
              key={t}
              className="reveal font-bold uppercase leading-[0.95] tracking-tight text-foreground/90"
              style={{ fontSize: "clamp(2rem, 6vw, 5rem)", transitionDelay: `${i * 80}ms` }}
            >
              <span className="font-mono text-xs text-muted-foreground align-top mr-4">0{i + 1}</span>
              {t}
            </h2>
          ))}
        </div>

        <div className="reveal mt-24 md:mt-32 text-center" style={{ transitionDelay: "400ms" }}>
          <div className="inline-block relative">
            <div className="absolute -inset-8 bg-primary/20 blur-3xl rounded-full" />
            <h3
              className="relative font-bold uppercase leading-none tracking-tight"
              style={{ fontSize: "clamp(2.5rem, 8vw, 7rem)" }}
            >
              so we <span className="text-acid text-glow">changed</span> <br />
              the system.
            </h3>
          </div>
        </div>
      </div>
    </section>
  );
};
