import { useReveal } from "@/hooks/use-reveal";

const quotes = [
  { id: "0x4f...a21b", name: "Lena · Vienna", q: "proud to own a piece of something real." },
  { id: "0x9c...e108", name: "Marco · Berlin", q: "first time my money felt like it belonged somewhere." },
  { id: "0x1a...77d4", name: "Sara · Lisbon", q: "i didn't invest. i joined." },
  { id: "0xb2...3f9e", name: "Tomáš · Brno", q: "the village is alive again. that's all i wanted." },
  { id: "0x66...c0a1", name: "Yara · Amsterdam", q: "this is what ownership should always have felt like." },
  { id: "0xfe...8821", name: "Jonas · Munich", q: "i have a key to a place i helped revive." },
];

const avatarColors = ["from-primary to-accent", "from-accent to-primary", "from-primary to-primary-glow", "from-accent to-primary-glow", "from-primary-glow to-accent", "from-primary to-accent"];

export const Community = () => {
  const ref = useReveal();
  return (
    <section ref={ref} className="py-32 md:py-44 relative">
      <div className="container">
        <div className="reveal max-w-3xl mb-16">
          <p className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground mb-6">/ 06 — the builders</p>
          <h2 className="font-bold uppercase leading-[0.95] tracking-tight" style={{ fontSize: "clamp(2.25rem, 6vw, 5rem)" }}>
            real people. <br /><span className="text-acid text-glow">real places.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quotes.map((q, i) => (
            <div
              key={q.id}
              className="reveal tilt-card glass rounded-2xl p-7"
              style={{ transitionDelay: `${i * 80}ms` }}
            >
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-11 h-11 rounded-full bg-gradient-to-br ${avatarColors[i]} ring-1 ring-primary/30`} />
                <div>
                  <div className="text-sm font-medium">{q.name}</div>
                  <div className="font-mono text-[10px] text-muted-foreground tracking-wider">builder · {q.id}</div>
                </div>
              </div>
              <p className="text-base leading-relaxed text-foreground/90">"{q.q}"</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
