import { Nav } from "@/components/Nav";
import { Hero } from "@/components/Hero";
import { Truth } from "@/components/Truth";
import { What } from "@/components/What";
import { Loop } from "@/components/Loop";
import { Project } from "@/components/Project";
import { Network } from "@/components/Network";
import { Community } from "@/components/Community";
import { FinalHook } from "@/components/FinalHook";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <main className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Nav />
      <Hero />
      <Truth />
      <What />
      <Loop />
      <Project />
      <Network />
      <Community />
      <FinalHook />
      <Footer />
    </main>
  );
};

export default Index;
